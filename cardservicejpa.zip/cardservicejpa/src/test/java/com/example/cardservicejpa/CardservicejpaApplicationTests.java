package com.example.cardservicejpa;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CardservicejpaApplicationTests {

	@Test
	void contextLoads() {
	}

}
