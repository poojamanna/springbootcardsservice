package com.example.cardservicejpa.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.cardservicejpa.model.Cards;
import com.example.cardservicejpa.service.CardService;

@Controller
//@RequestMapping("/api")
public class CardsController {
	@Autowired
	private CardService cardService;
	@GetMapping("/")
    public String viewHomePage(Model model) {
        model.addAttribute("listCards", cardService.getAllCards());
        return "cards";
    }
	
	/*
	 * @GetMapping("/cards") public ResponseEntity<List<Cards>> getAllCards(){
	 * return ResponseEntity.ok().body(cardService.getAllCards()); }
	 * 
	 * @GetMapping("/cards/{id}") public ResponseEntity<Cards>
	 * getCardById(@PathVariable long id){ return
	 * ResponseEntity.ok().body(cardService.getCardById(id)); }
	 */
	@GetMapping("/cardform")
	    public String cardform(Model model) {
	        // create model attribute to bind form data
		Cards cards = new Cards();
	        model.addAttribute("cards", cards);
	        return "newcard";
	    }
	 @PostMapping("/createCard")
	    public String createCard(@ModelAttribute("cards") Cards cards) {
	        // save employee to database
		 cardService.createCard(cards);
	        return "redirect:/";
	    }

		/*
		 * @PostMapping("/cards") public ResponseEntity<Cards> createCard(@RequestBody
		 * Cards cards){ return
		 * ResponseEntity.ok().body(this.cardService.createCard(cards)); }
		 */
		/*
		 * @DeleteMapping("/cards/{id}") public HttpStatus deleteCard(@PathVariable long
		 * id){ this.cardService.deleteCard(id); return HttpStatus.OK; }
		 */
	 @GetMapping("/deleteCards/{id}")
	    public String deleteCards(@PathVariable(value = "id") long id) {

	        // call delete card method 
	        this.cardService.deleteCard(id);
	        return "redirect:/";
	    }
}
