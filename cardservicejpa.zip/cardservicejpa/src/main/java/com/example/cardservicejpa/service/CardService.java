package com.example.cardservicejpa.service;

import java.util.List;

import com.example.cardservicejpa.model.Cards;

public interface CardService {
Cards createCard(Cards cards);
List<Cards> getAllCards();
Cards getCardById(long cardid);
void deleteCard(long cardid);
}
 