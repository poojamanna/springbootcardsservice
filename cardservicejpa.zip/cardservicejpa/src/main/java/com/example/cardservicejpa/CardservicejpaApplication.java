package com.example.cardservicejpa;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


@SpringBootApplication
public class CardservicejpaApplication {

	public static void main(String[] args) {
		SpringApplication.run(CardservicejpaApplication.class, args);
	}

}
