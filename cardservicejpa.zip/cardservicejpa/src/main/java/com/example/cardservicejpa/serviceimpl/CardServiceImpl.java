package com.example.cardservicejpa.serviceimpl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.example.cardservicejpa.exception.ResourceNotFoundException;
import com.example.cardservicejpa.model.Cards;
import com.example.cardservicejpa.repository.CardsRepository;
import com.example.cardservicejpa.service.CardService;

@Service
@Transactional
public class CardServiceImpl implements CardService{
	@Autowired
	private CardsRepository cardsRepository;
	
	
	@Override
	public Cards createCard(Cards cards) {
		return cardsRepository.save(cards);
	}
	
	@Override
	public List<Cards> getAllCards() {
		return this.cardsRepository.findAll();
	}
	
	@Override
	public Cards getCardById(long cardid) {
		
		Optional<Cards> cardDb = this.cardsRepository.findById(cardid);
		
		if(cardDb.isPresent()) {
			return cardDb.get();
		}else {
			return null;
		}
	}
	@Override
	public void deleteCard(long cardid) {
		Optional<Cards> cardDb = this.cardsRepository.findById(cardid);
		
		if(cardDb.isPresent()) {
			this.cardsRepository.delete(cardDb.get());
		}else {
			throw new ResourceNotFoundException("Record not found with id : " + cardid);
		}
		
	}
	
	
}
