package com.example.cardpaymentservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CardpaymentserviceApplication {

	public static void main(String[] args) {
		SpringApplication.run(CardpaymentserviceApplication.class, args);
	}

}
