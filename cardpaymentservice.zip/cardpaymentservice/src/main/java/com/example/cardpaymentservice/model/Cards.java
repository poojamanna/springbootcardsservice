package com.example.cardpaymentservice.model;

import java.sql.Date;

public class Cards {
private int cardid;
private String cardnumber;
private String cardholder;
private String cardcvv;
private Date expdate;
private String totalamount;

public Cards() {
	
}

public Cards(int cardid, String cardnumber, String cardholder, String cardcvv, Date expdate, String totalamount) {
	super();
	this.cardid = cardid;
	this.cardnumber = cardnumber;
	this.cardholder = cardholder;
	this.cardcvv = cardcvv;
	this.expdate = expdate;
	this.totalamount = totalamount;
}
public int getCardid() {
	return cardid;
}
public void setCardid(int cardid) {
	this.cardid = cardid;
}
public String getCardnumber() {
	return cardnumber;
}
public void setCardnumber(String cardnumber) {
	this.cardnumber = cardnumber;
}
public String getCardholder() {
	return cardholder;
}
public void setCardholder(String cardholder) {
	this.cardholder = cardholder;
}
public String getCardcvv() {
	return cardcvv;
}
public void setCardcvv(String cardcvv) {
	this.cardcvv = cardcvv;
}
public Date getExpdate() {
	return expdate;
}
public void setExpdate(Date expdate) {
	this.expdate = expdate;
}
public String getTotalamount() {
	return totalamount;
}
public void setTotalamount(String totalamount) {
	this.totalamount = totalamount;
}
@Override
public String toString() {
	return "Cards [cardid=" + cardid + ", cardnumber=" + cardnumber + ", cardholder=" + cardholder + ", cardcvv="
			+ cardcvv + ", expdate=" + expdate + ", totalamount=" + totalamount + "]";
}
}
