package com.example.cardpaymentservice.model;

public class Transactions {

}
