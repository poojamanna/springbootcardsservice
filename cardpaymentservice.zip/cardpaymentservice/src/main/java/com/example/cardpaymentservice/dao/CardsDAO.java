package com.example.cardpaymentservice.dao;

import java.util.List;

import com.example.cardpaymentservice.model.Cards;

public interface CardsDAO {
public List<Cards> viewAllCards();
}
