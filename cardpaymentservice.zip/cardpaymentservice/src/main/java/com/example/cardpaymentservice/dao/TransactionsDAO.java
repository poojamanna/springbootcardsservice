package com.example.cardpaymentservice.dao;

public class TransactionsDAO {

}
