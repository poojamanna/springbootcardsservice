package com.example.cardpaymentservice.daoimpl;

public class TransactionsDAOImpl {

}
