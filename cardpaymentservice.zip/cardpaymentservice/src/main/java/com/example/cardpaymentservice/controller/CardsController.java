package com.example.cardpaymentservice.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.cardpaymentservice.dao.CardsDAO;

@RestController
public class CardsController {

	@Autowired
	private CardsDAO cardDAO;
	
	@GetMapping("/cards")
	public List getCards() {	
	return cardDAO.viewAllCards();
	}
	/*
	 * @RequestMapping(value="/index") public String index() { return "index";
	 * 
	 * }
	 */
}
